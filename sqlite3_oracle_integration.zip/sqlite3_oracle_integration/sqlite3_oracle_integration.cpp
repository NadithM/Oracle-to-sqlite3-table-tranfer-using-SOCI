// sqlite3_oracle_integration.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "soci.h"
#include "soci-oracle.h"
#include "common-tests.h"
#include <iostream>
#include <string>
#include <cstring>
#include <cassert>
#include <iomanip>
#include <ctime>
#include "soci-sqlite3.h"
#include <sstream>
#include <cassert>
#include <cmath>


using namespace soci;
using namespace std;
using namespace soci::tests;



vector<string> GenerateDataTypes(vector<string> input_datatypes,vector<int> input_dp,vector<int> input_ds,vector<int> input_dl,int Insize){

	
	vector<string> output;


	for (unsigned i=0; i<Insize; ++i){
		string teststr = (input_datatypes)[i] ;
		int test_pre=  input_dp[i] ;


		if(teststr.find("NUMBER") != std::string::npos){
			if(input_ds[i]!=NULL){
				std::ostringstream stream;
				stream << "DECIMAL("<< input_dp[i] << ","<<input_ds[i]<<")";
				std::string result = stream.str();
				output.push_back(result);
			}else
				output.push_back("INT");
			//cout <<"\tNUMBER  found \n";
		}
		else if(teststr.find("INTEGER") != std::string::npos)
			output.push_back("INT");
		else if(teststr.find("DOUBLE") != std::string::npos)
			output.push_back("DOUBLE");
		else if(teststr.find("BINARY_DOUBLE") != std::string::npos)
			output.push_back("DOUBLE");
		else if(teststr.find("BINARY_FLOAT") != std::string::npos)
			output.push_back("FLOAT");
		else if(teststr.find("FLOAT") != std::string::npos)
		output.push_back("FLOAT");
		else if(teststr.find("NCHAR") != std::string::npos)
					output.push_back("TEXT");
		else if(teststr.find("NVARCHAR") != std::string::npos)
					output.push_back("VARCHAR");
		else if(teststr.find("VARCHAR2") != std::string::npos){
			if(input_dl[i]<255)
				output.push_back("TEXT");
			else output.push_back("TEXT");
					
		}
		else if(teststr.find("CHAR") != std::string::npos)
					output.push_back("CHAR");
		else if(teststr.find("CLOB") != std::string::npos)
					output.push_back("CLOB");
		else if(teststr.find("DATE") != std::string::npos)
					output.push_back("DATE");
		else if(teststr.find("TIMESTAMP") != std::string::npos)
					output.push_back("DATETIME");
		else if(teststr.find("BLOB") != std::string::npos){
					output.push_back("BLOB");
					//cout <<"BLOB found \n";
		}


	}
	return output;
}

string getmonth(int mon){
	if(mon==0) return "JAN";
	else if(mon==1) return "FEB";
	else if(mon==2) return "MAR";
	else if(mon==3) return "APR";
	else if(mon==4) return "MAY";
	else if(mon==5) return "JUN";
	else if(mon==6) return "JUL";
	else if(mon==7) return "AUG";
	else if(mon==8) return "SEP";
	else if(mon==9) return "OCT";
	else if(mon==10) return "NOV";
	else if(mon==11) return "DEC";


}

string notnull(string col,vector<string> nulllist,string type){

	for(int i=0;i<nulllist.size();i++){

		if(type=="BLOB" || type=="CLOB")
			return "";
	
		else if(col==nulllist[i])
			return " NOT NULL";
	}

	return "";
}

string primarykey(vector<string> primarylist){

	if(primarylist.size()==0)	return "";

	string first=",\nPRIMARY KEY(";
	for(int i=0;i<primarylist.size();i++){
		first=first+primarylist[i];
		if(i==primarylist.size()-1);
		else	first=first+",";
	}
	first=first+")";

	return first;
}

string to_string(int number){
    string number_string = "";
    char ones_char;
    int ones = 0;
    while(true){
        ones = number % 10;
        switch(ones){
            case 0: ones_char = '0'; break;
            case 1: ones_char = '1'; break;
            case 2: ones_char = '2'; break;
            case 3: ones_char = '3'; break;
            case 4: ones_char = '4'; break;
            case 5: ones_char = '5'; break;
            case 6: ones_char = '6'; break;
            case 7: ones_char = '7'; break;
            case 8: ones_char = '8'; break;
            case 9: ones_char = '9'; break;
            default :  throw "Trouble converting number to string.";
        }
        number -= ones;
        number_string = ones_char + number_string;
        if(number == 0){
            break;
        }
        number = number/10;
    }
    return number_string;
}

string append(string left,double right){
	ostringstream strs;
	strs << "'"<<right<<"'";
	string str = strs.str();
	left=left+str;

	return left;
}

string append(string left,int right){
	ostringstream strs;
	strs << "'"<<right<<"'";
	string str = strs.str();
	left=left+str;

	return left;
}

string append(string left,long long right){
	ostringstream strs;
	strs << "'"<<right<<"'";
	string str = strs.str();
	left=left+str;

	return left;
}

string append(string left,unsigned long long right){
	ostringstream strs;
	strs << "'"<<right<<"'";
	string str = strs.str();

	//cout <<str;
	left=left+str;

	return left;
}

string format_num(int test_number){

if(test_number<10)
	return std::string(1, '0').append(to_string(test_number));
else return to_string(test_number);

}

bool replace(std::string& str, const std::string& from, const std::string& to) {
    size_t start_pos = str.find(from);
    if(start_pos == std::string::npos)
        return false;
    str.replace(start_pos, from.length(), to);
    return true;
}

string formatDateTime(std::tm when,string format){


	string day=format_num(when.tm_mday);
	string month=format_num(when.tm_mon+1);
	string hour=format_num(when.tm_hour);
	string min=format_num(when.tm_min);
	string sec=format_num(when.tm_sec);
	//cout <<day;

	if(format.find("HH") != std::string::npos && format.find("MI") != std::string::npos && format.find("SS") != std::string::npos){
	

	replace(format,"YYYY",to_string(when.tm_year+1900));
	replace(format,"YY",to_string(when.tm_year-100));
	replace(format,"MM",month);
	replace(format,"DD",day);
	replace(format,"HH",hour);
	
	replace(format,"MI",min);
	replace(format,"SS",sec);
	replace(format,"MON",getmonth(when.tm_mday));
	}
	else{
	replace(format,"YYYY",to_string(when.tm_year+1900));
	replace(format,"YY",to_string(when.tm_year-100));
	replace(format,"MM",month);
	replace(format,"DD",day);
	}

return format;

}

vector<string> split(const std::string &s, char delim) {
    vector<string> elems;
	std::stringstream ss;
    ss.str(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }

	return elems;
}



string GetColumnNameString(string insert,vector<string> d_types1,vector<string> col_names1){
	string without_blob="";
		for(int j=0;j<d_types1.size();j++){
			if(d_types1[j]=="BLOB" || d_types1[j]=="blob"||d_types1[j]=="CLOB" || d_types1[j]=="clob");
			else without_blob=without_blob+col_names1[j]+",";
			
		}
		without_blob=without_blob.substr (0,without_blob.length()-1);

		//cout <<without_blob;

return insert+without_blob+" ";
}

string get_select_statment_without_blob(string table_name,vector<string> d_types1,vector<string> col_names1){
	string without_blob="select ";
		for(int j=0;j<d_types1.size();j++){
			if(d_types1[j]=="BLOB" || d_types1[j]=="blob"||d_types1[j]=="CLOB" || d_types1[j]=="clob");
			else without_blob=without_blob+col_names1[j]+",";
			
		}
		without_blob=without_blob.substr (0,without_blob.length()-1);

		//cout <<without_blob;

return without_blob+" from "+table_name;
}


int no_of_lobs(vector<string> d_types1){
	int count=0;
		for(int j=0;j<d_types1.size();j++){
			if(d_types1[j]=="BLOB" || d_types1[j]=="blob"||d_types1[j]=="CLOB" || d_types1[j]=="clob")count++;
			
		}

return count;
}

vector<string> getBlobs(vector<string> col_names,vector<string> d_types){
	vector<string> bloblist;

	for(int j=0;j<d_types.size();j++){
		if(d_types[j]=="BLOB" || d_types[j]=="blob") bloblist.push_back(col_names[j]);
			
	}


return bloblist;
}

vector<string> getClobs(vector<string> col_names,vector<string> d_types){
	vector<string> cloblist;

	for(int j=0;j<d_types.size();j++){
		if(d_types[j]=="CLOB" || d_types[j]=="clob") cloblist.push_back(col_names[j]);
			
	}


return cloblist;
}

void BLOBTEST(int BUFSIZE,char * array1,char * array2){

	for(int w=0;w<BUFSIZE;w++)
			assert(array1[w] == array2[w]);

}

void update_CLOBS(string table_name,session &sql,session & sql_sqlite3,vector<string> d_types,vector<string> col_names,string conditions){

	vector<string> cloblist=getClobs(col_names,d_types);
	if(cloblist.size()==0) return;

	for(int u=0;u<cloblist.size();u++){
		string temp_str;
		string temp_select="select "+cloblist[u]+ " from "+table_name+" "+conditions; 

		//------
		indicator ind;
		string temp_update;
		string check_select;

		sql << temp_select, into(temp_str, ind);

		if (sql.got_data())
		{
			switch (ind)
			{
			case i_ok:
		
				// the data was returned without problem
				//cout<<"CLOB-DATA set"<<temp_str<<"\n";
				temp_update="update "+table_name+ " set "+cloblist[u]+"=:placeholder "+conditions; 
				sql_sqlite3<< temp_update,use(temp_str);
				check_select="select "+cloblist[u]+ " from "+table_name+" "+conditions;
				sql_sqlite3<< check_select, into(temp_str);
				//cout<<"CLOB-DATA get"<<temp_str<<"\n";

				break;
			case i_null:

				break;
			case i_truncated:
				
				break;
			}
		}
		else
		{
		}

			
	}

}



void update_LOBS(string table_name,session &sql,session & sql_sqlite3,vector<string> d_types,vector<string> col_names,string conditions){

	blob b(sql); // sql is a session object
	blob bcopy(sql_sqlite3);

	vector<string> bloblist=getBlobs(col_names,d_types);

	for(int u=0;u<bloblist.size();u++){

		string temp_select="select "+bloblist[u]+ " from "+table_name+" "+conditions; 
		sql << temp_select, into(b);
		
		//std::size_t get_len();
		//std::size_t read(std::size_t offset, char *buf, std::size_t toRead);

			const unsigned int BUFSIZE=b.get_len();
			char *buffer_oracle=new char[BUFSIZE];
			char *buffer_sqlite3=new char[BUFSIZE];
			unsigned int readAmt=BUFSIZE;
			unsigned int offset=1;

			b.read(offset,buffer_oracle,readAmt);

			//printf("blob in oracle is %s\n", buffer_oracle);

	
			//std::size_t write(std::size_t offset, char const *buf, std::size_t toWrite);
			bcopy.write(offset,buffer_oracle,readAmt);

			string temp_update="update "+table_name+ " set "+bloblist[u]+"=:placeholder "+conditions; 
			sql_sqlite3<< temp_update,use(bcopy);
		
			
			blob bcopy2(sql_sqlite3);
			string check_select="select "+bloblist[u]+ " from "+table_name+" "+conditions;
			sql_sqlite3<< check_select, into(bcopy2);

			bcopy2.read(offset,buffer_sqlite3,readAmt);

			//printf("blob in sqlite3 is %s\n", buffer_oracle);

			BLOBTEST(BUFSIZE,buffer_oracle,buffer_sqlite3);
			delete(buffer_oracle);
			delete(buffer_sqlite3);
			
	}


}

string replaceQuoteAll(string target){

	vector<string> parts=split(target,39);
	string temp="";
	for(int i=0;i<parts.size();i++){
		temp=temp+parts[i]+"''";
	}
	temp=temp.substr (0,temp.length()-2);

return temp;
}


string GetCreateTableStatment(string table_name,vector<string> col_names,vector<string> d_types_sqlite,vector<string> d_null,vector<string> d_pri){

	string temp_create="create table "+table_name+"(\n";
	string rest="";
	for(int j=0;j<col_names.size();j++){
		temp_create=temp_create+col_names[j]+" "+d_types_sqlite[j]+notnull(col_names[j],d_null,d_types_sqlite[j]);
		if(j==col_names.size()-1);
		else	temp_create=temp_create+",\n";
	}
	temp_create=temp_create+primarykey(d_pri);
	temp_create=temp_create+"\n)";
	
	//cout <<temp_create<<"\n";

	return temp_create;
}

string constructKey(string key,string column_name,string value,vector<string> d_pri){

	for(int j=0;j<d_pri.size();j++){
		if(d_pri[j]==column_name)key=key+" "+column_name+"="+value+" and" ;
	}

	return key;

}

bool DropTableSqlite3(string table_name,session &sql_sqlite3){

	try{
		sql_sqlite3<<"drop table "+table_name;
		cout <<"\nSQLITE3 TABLE "+table_name+ " DROPED SUCCESSFULLY\n";

		return true;
    }
	 catch (exception const &e)
    {
        cerr << "Some other error: " << e.what() << endl;
		return false;
    }
	

}

bool ConvertTableOracle2sqlite3(string table_name,session & sql,session & sql_sqlite3){
 try
    {	

		/*
			Ex.2016-JAN-25 13:34:01 
			:use only 
			YYYY for 2016,
			YY for 16,
			MM for 01,
			MON for JAN,
			DD for 25,
			HH for 13 ,
			MI for 34,
			SS for 01 
			any ORDER as in the oracle DB you like
		*/ 
		string datetimeformat="YYYY-MM-DD";
		vector<string> col_names;
		vector<string> d_types;
		vector<int> d_preci;
		vector<int> d_scale;
		vector<int> d_length;
		vector<string>d_null(1000);
		vector<string>d_pri(10);
		vector<indicator> inds_dt;
		int data_count=0;
		int col_count=0;
	
		//get required table MetaData.if NULL value return for string -"" for number -0
		string initial_data="SELECT column_name,data_type,DATA_PRECISION,DATA_SCALE,DATA_LENGTH FROM USER_TAB_COLUMNS WHERE table_name = '"+table_name+"'";
		rowset<row> row_set = (sql.prepare << initial_data);
		
		for (rowset<row>::const_iterator it = row_set.begin(); it != row_set.end(); ++it)
		{
			row const& roww = *it;
			
			for(int k=0;k<5;k++){
				
				const column_properties & props = roww.get_properties(k);

				switch(props.get_data_type())
				{
				
				case dt_string:
					if(props.get_name()=="COLUMN_NAME") col_names.push_back(roww.get<string>(k));
					else if(props.get_name()=="DATA_TYPE") d_types.push_back(roww.get<string>(k));
					
					break;
				case dt_double:
					if(props.get_name()=="DATA_PRECISION") d_preci.push_back(roww.get<double>(k,0));
					else if(props.get_name()=="DATA_SCALE") d_scale.push_back(roww.get<double>(k,0));
					else if(props.get_name()=="DATA_LENGTH")d_length.push_back(roww.get<double>(k,0));
					
					break;
				case dt_integer:
					if(props.get_name()=="DATA_PRECISION") d_preci.push_back(roww.get<int>(k,0));
					else if(props.get_name()=="DATA_SCALE") d_scale.push_back(roww.get<int>(k,0));
					else if(props.get_name()=="DATA_LENGTH")d_length.push_back(roww.get<int>(k,0));
					break;
				case dt_long_long:
					if(props.get_name()=="DATA_PRECISION") d_preci.push_back(roww.get<long long>(k,0));
					else if(props.get_name()=="DATA_SCALE") d_scale.push_back(roww.get<long long>(k,0));
					else if(props.get_name()=="DATA_LENGTH")d_length.push_back(roww.get<long long>(k,0));
					break;
				case dt_unsigned_long_long:
					if(props.get_name()=="DATA_PRECISION") d_preci.push_back(roww.get<unsigned long long>(k,0));
					else if(props.get_name()=="DATA_SCALE") d_scale.push_back(roww.get<unsigned long long>(k,0));
					else if(props.get_name()=="DATA_LENGTH")d_length.push_back(roww.get<unsigned long long>(k,0));
					break;
				
				
				}
			}


		}
		
		sql<< "SELECT distinct column_name FROM all_cons_columns WHERE constraint_name = (SELECT constraint_name FROM user_constraints WHERE UPPER(table_name) = UPPER('"+table_name+"') AND CONSTRAINT_TYPE = 'P')",into(d_pri,inds_dt);
		sql<< "select column_name from USER_TAB_COLUMNS where table_name='"+table_name+"' and nullable='N'",into(d_null,inds_dt);
		sql << " select count(*) from (SELECT column_name FROM USER_TAB_COLUMNS WHERE table_name = '"+table_name+"')",into(col_count);

		//cout << "entries count is : "<<count<<"\n" ;
		//cout << "columns count is : "<<count<<"\n" ;
/*
		col_names.shrink_to_fit();
		d_types.shrink_to_fit();
		d_preci.shrink_to_fit();
		d_scale.shrink_to_fit();
		d_length.shrink_to_fit();
		
*/

		d_null.shrink_to_fit();
		d_pri.shrink_to_fit();
		//get the sqlite corresponding datatypes for oracle datatypes
		vector<string> d_types_sqlite=GenerateDataTypes(d_types,d_preci,d_scale,d_length,d_types.size());

		//get string statment to create the table
		string temp_create=GetCreateTableStatment(table_name,col_names,d_types_sqlite,d_null,d_pri);

		sql_sqlite3 << temp_create;
		cout <<"SQLITE3 TABLE "+table_name+ " CREATED SUCCESSFULLY\n";

		//get select statment in oracle without blob type
		string oracle_select=get_select_statment_without_blob(table_name,d_types,col_names);
		
		//result set
		rowset<row> rs = (sql.prepare << oracle_select);
		
		int raw_count=0;
		int col_value1=0;
		string col_value2="";
		double col_value3=0.0;
		long long col_value4=0;
		unsigned long long col_value5=0;
		string col_date="";
		std::tm when;

		string test_check="where";
		
		//get the string of columns_names except blob/clob data type sperated by comma
		string temp_string=GetColumnNameString("",d_types,col_names);
		//columnlist of where condition is needed to update blob/clob
		vector<string> condition=split(temp_string,',');

		for (rowset<row>::const_iterator it = rs.begin(); it != rs.end(); ++it)
		{
			raw_count++;
			row const& r = *it;

			string conditions="where";
			string key="where ";
			string insert="insert into "+table_name+" (";
			insert=GetColumnNameString(insert,d_types,col_names)+") values(";
			
			// dynamic data extraction from each row:
			
			for(int k=0;k<col_count-no_of_lobs(d_types);k++){
				
				const column_properties & props = r.get_properties(k);

				switch(props.get_data_type())
				{
				
				case dt_string:
					col_value2=r.get<string>(k,"");
					if(col_value2.find("'") != std::string::npos){
						col_value2=replaceQuoteAll(col_value2);
					}
					insert=insert+"'"+col_value2+"'";
					if(d_pri.size()!=0)key=constructKey(key,props.get_name(),("'"+col_value2+"'"),d_pri);
					conditions=conditions+" "+condition[k]+"="+"'"+col_value2+"' and" ;
					break;
				case dt_double:
					col_value3=r.get<double>(k);
					insert=append(insert,col_value3);
					if(d_pri.size()!=0)key=constructKey(key,props.get_name(),append("",col_value3),d_pri);
					conditions=conditions+" "+condition[k]+"="+append("",col_value3)+" and" ;
					break;
				case dt_integer:
					col_value1=r.get<int>(k);
					insert=append(insert,col_value1);
					if(d_pri.size()!=0)key=constructKey(key,props.get_name(),append("",col_value1),d_pri);
					conditions=conditions+" "+condition[k]+"="+append("",col_value1)+" and" ;
					break;
				case dt_long_long:
					col_value4=r.get<long long>(k);
					insert=append(insert,col_value4);
					if(d_pri.size()!=0)key=constructKey(key,props.get_name(),append("",col_value4),d_pri);
					conditions=conditions+" "+condition[k]+"="+append("",col_value4)+" and" ;
					break;
				case dt_unsigned_long_long:
					col_value5=r.get<unsigned long long>(k);
					insert=append(insert,col_value5);
					if(d_pri.size()!=0)key=constructKey(key,props.get_name(),append("",col_value5),d_pri);
					conditions=conditions+" "+condition[k]+"="+append("",col_value5)+" and" ;
					break;
				case dt_date:
					when = r.get<std::tm>(k);

					string date=formatDateTime(when,datetimeformat);

					insert=insert+"'"+date+"'";
					if(d_pri.size()!=0)key=constructKey(key,props.get_name(),("'"+date+"'"),d_pri);
					conditions=conditions+" "+condition[k]+"="+"'"+date+"' and" ;
					break;



				
				}


				insert=insert+",";

				}
				insert=insert.substr (0,insert.length()-1)+")";
				conditions=conditions.substr(0,conditions.length()-4);
				key=key.substr(0,key.length()-4);
	
				//final insert query for sqlite3
				sql_sqlite3<< insert;

				//-----------------------------------------------------------------------


				row rw;
				string sqlite3_select;

				if(d_pri.size()!=0)
					sqlite3_select=	oracle_select+" "+key;
				else
					sqlite3_select=oracle_select+" "+conditions;

				//cout <<sqlite3_select<<"\n";
				sql_sqlite3 << sqlite3_select, into(rw);

				// dynamic data extraction from each row:
				for(int k=0;k<col_count-no_of_lobs(d_types);k++){
				
					const column_properties & props = rw.get_properties(k);

					switch(props.get_data_type())
					{
					case dt_string:
					col_value2=rw.get<string>(k,"");
					if(col_value2.find("'") != std::string::npos){
						col_value2=replaceQuoteAll(col_value2);
					}
					test_check=test_check+" "+condition[k]+"="+"'"+col_value2+"' and" ;
					break;
					case dt_double:
						col_value3=rw.get<double>(k);
						test_check=test_check+" "+condition[k]+"="+append("",col_value3)+" and" ;
						break;
					case dt_integer:
						col_value1=rw.get<int>(k);
						test_check=test_check+" "+condition[k]+"="+append("",col_value1)+" and" ;
						break;
					case dt_long_long:
						col_value4=rw.get<long long>(k);
						test_check=test_check+" "+condition[k]+"="+append("",col_value4)+" and" ;
						break;
					case dt_unsigned_long_long:
						col_value5=rw.get<unsigned long long>(k);
						test_check=test_check+" "+condition[k]+"="+append("",col_value5)+" and" ;
						break;
					case dt_date:
						when = rw.get<std::tm>(k);
						string date=formatDateTime(when,datetimeformat);
						test_check=test_check+" "+condition[k]+"="+"'"+date+"' and" ;
						break;
					}

				}
				test_check=test_check.substr(0,test_check.length()-4);


				//cout<< test_check<<"\n";

				//cout<<conditions<<"\n";
				//cout<<".";
				assert(test_check==conditions);

				test_check="where";

			//--------------------------------------------------------------------------
				if(d_pri.size()!=0){
					update_LOBS(table_name,sql,sql_sqlite3,d_types,col_names,key);
					update_CLOBS(table_name,sql,sql_sqlite3,d_types,col_names,key);
				}
				else{
					update_LOBS(table_name,sql,sql_sqlite3,d_types,col_names,conditions);
					update_CLOBS(table_name,sql,sql_sqlite3,d_types,col_names,conditions);
				}
			
			cout<<".";
		}
	
		cout<<"\nBLOB DATA TEST IS PASSED\n";
		cout<<"\nCLOB DATA TEST IS PASSED\n";
		cout<< "\nALL DATA TYPES TEST IS PASSED.\n";
		cout<< "\nORACLE TO SQLLITE3 TABLE DATA TRANFER IS FINISHED.\n";
		
		return true;
    }
    catch (oracle_soci_error const & e)
    {
        cerr << "Oracle error: " << e.err_num_
            << " " << e.what() << endl;
		DropTableSqlite3(table_name,sql_sqlite3);
		return false;
    }
    catch (exception const &e)
    {
        cerr << "Some other error: " << e.what() << endl;
		DropTableSqlite3(table_name,sql_sqlite3);
		return false;
    }


}




int _tmain(int argc, _TCHAR* argv[])
{//ATS_XMAN_ACTIVITY_LOG
	 try
    { 

		session sql("oracle", "service=172.25.76.180:1521/mccpdb user=ccpd61 password=ccpd61");
		session sql_sqlite3(sqlite3, "sqlte3_database");
		string table_name="BDB";

		bool flag=ConvertTableOracle2sqlite3(table_name,sql,sql_sqlite3);

		if(flag==true) cout <<"\nTable Convertion was Success\n";
		else	{
			cout <<"\nTable Convertion was Unsuccess\n";
			
		}
		//DropTableSqlite3(table_name,sql_sqlite3);
		getchar();
        return EXIT_SUCCESS;
    }
    catch (std::exception const & e)
    {
        std::cout << e.what() << '\n';
    }
	


    return EXIT_FAILURE;
	getchar();
	return 0;
}

